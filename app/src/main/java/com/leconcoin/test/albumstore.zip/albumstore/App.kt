package com.leconcoin.test.albumstore

import android.app.Application
import androidx.room.Room
import com.leconcoin.test.albumstore.repository.database.AppDatabase
import com.leconcoin.test.albumstore.repository.database.DATABASE_NAME
import timber.log.Timber
import toothpick.Toothpick
import toothpick.smoothie.module.SmoothieApplicationModule

class App : Application() {

    companion object {
        lateinit var db: AppDatabase
    }

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(
            this,
            AppDatabase::class.java,
            DATABASE_NAME
        ).build()
        setUpToothpick()
        Timber.plant(Timber.DebugTree())
    }

    private fun setUpToothpick() {
        // Toothpick
        val appScope = Toothpick.openScope(this)
        appScope.installModules(SmoothieApplicationModule(this), ApplicationModule(this))

    }
}