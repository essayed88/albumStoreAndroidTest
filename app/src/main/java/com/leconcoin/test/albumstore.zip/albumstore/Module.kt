package com.leconcoin.test.albumstore

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import com.leconcoin.test.albumstore.repository.api.AlbumClient
import com.leconcoin.test.albumstore.repository.database.AlbumDao
import toothpick.config.Module

class ApplicationModule(application: App) : Module() {

    init {
        bind(SharedPreferences::class.java).toInstance(getSharedPreferences(application))
        bind(AlbumClient::class.java).toInstance(AlbumClient(application))
    }

    private fun getSharedPreferences(application: Application) = application.getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE)
}