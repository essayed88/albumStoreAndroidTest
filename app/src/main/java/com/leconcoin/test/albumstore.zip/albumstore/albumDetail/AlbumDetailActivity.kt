package com.leconcoin.test.albumstore.albumDetail

import androidx.lifecycle.Observer
import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.BaseActivity
import com.leconcoin.test.albumstore.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_album.*
import javax.inject.Inject


class AlbumDetailActivity : BaseActivity(R.layout.activity_album_detail) {

    companion object {
        const val EXTRA_BOOK_ID = "albumId"
    }

    @Inject
    lateinit var viewModel: IAlbumDetailViewModel

    override fun injectionModule() = AlbumDetailModule(this)

    override fun afterInject() {
        val albumId = intent.getIntExtra(EXTRA_BOOK_ID, 1)

        viewModel.getAlbumById(albumId)
        viewModel.observeAlbum().observe(this, Observer { album -> updateAlbum(album!!) })
    }

    private fun updateAlbum(album: Album) {
        Picasso.get()
            .load(album.url)
            .placeholder(R.drawable.ic_placeholder_image)
            .into(albumCover)

        albumTitle.text = album.title
        albumId.text = album.albumId.toString()
    }

}