package com.leconcoin.test.albumstore.repository.database


import androidx.lifecycle.MutableLiveData
import io.reactivex.Completable
import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers


fun <T> Single<T>.ioToMainThread(): Single<T> = subscribeOn(Schedulers.io())
    .observeOn(AndroidSchedulers.mainThread())

fun Completable.ioToMainThread(): Completable = subscribeOn(Schedulers.io())
    .observeOn(AndroidSchedulers.mainThread())

fun <T> Single<T>.asyncToMainThread(): Single<T> = subscribeOn(Schedulers.computation())
    .observeOn(AndroidSchedulers.mainThread())

fun <T> Flowable<T>.ioToMainThread(): Flowable<T> = subscribeOn(Schedulers.io())
    .observeOn(AndroidSchedulers.mainThread())

fun <T> Observable<T>.ioToMainThread(): Observable<T> = subscribeOn(Schedulers.io())
    .observeOn(AndroidSchedulers.mainThread())

fun <T> Single<T>.fetch(errorEvent: MutableLiveData<Throwable>) {
    doOnError { errorEvent.postValue(it) }
        .ioToMainThread()
}

fun <T> Flowable<T>.fetch(errorEvent: MutableLiveData<Throwable>) {
    doOnError { errorEvent.postValue(it) }
        .ioToMainThread()
}