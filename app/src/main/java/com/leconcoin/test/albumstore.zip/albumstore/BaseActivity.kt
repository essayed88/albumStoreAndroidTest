package com.leconcoin.test.albumstore


import android.os.Bundle
import androidx.annotation.CallSuper
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.leconcoin.test.albumstore.di.ViewModelFactory
import toothpick.Toothpick
import toothpick.config.Module
import toothpick.smoothie.module.SmoothieActivityModule
import toothpick.smoothie.module.SmoothieSupportActivityModule

abstract class BaseActivity(@LayoutRes private val layoutResourceId: Int) : AppCompatActivity() {

    abstract fun injectionModule(): Module

    open fun afterInject() {}

    /*
     * *********************************************************************************************
     * DATA
     * *********************************************************************************************
     */

    private var savedInstanceState: Bundle? = null


    /*
     * *********************************************************************************************
     * UI
     * *********************************************************************************************
     */


    var dialogProgress: AlertDialog? = null

    /*
     * *********************************************************************************************
     * LIFECYCLE METHODS
     * *********************************************************************************************
     */

    @CallSuper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layoutResourceId)
        injectDependencies()
        this.savedInstanceState = savedInstanceState
    }

    @CallSuper
    override fun onDestroy() {
        Toothpick.closeScope(this)
        super.onDestroy()
    }

    /*
    * *********************************************************************************************
    * PUBLIC METHODS
    * *********************************************************************************************
    */

    fun <T : ViewModel> getViewModel(viewModelClass: Class<T>): T = ViewModelProviders.of(
        this, Toothpick.openScopes(application)
            .getInstance(ViewModelFactory::class.java)
    )
        .get(viewModelClass)
/*
    fun showProgressDialog() {
        DeviceUtils.lockScreenOrientation(this)

        dismissProgressDialogIfExist()
        dialogProgress = ProgressDialogUtils.showProgressDialog(this, false)
        dialogProgress?.show()
    }

    fun dismissProgressDialogIfExist() {
        DeviceUtils.unlockScreenOrientation(this)

        dialogProgress?.let {
            it.dismiss()
            dialogProgress = null
        }
    }
*/
    /*
     * *********************************************************************************************
     * PRIVATE METHODS
     * *********************************************************************************************
     */

    private fun injectDependencies() {
        val activityScope = Toothpick.openScopes(application, this)
        activityScope.installModules(
            SmoothieSupportActivityModule(this),
            SmoothieActivityModule(this),
            injectionModule()
        )
        Toothpick.inject(this, activityScope)
        afterInject()
    }

    private fun getSavedInstanceState(): Bundle? {
        return savedInstanceState
    }

    /*
     * *********************************************************************************************
     * OPEN METHODS
     * *********************************************************************************************
     */
}
