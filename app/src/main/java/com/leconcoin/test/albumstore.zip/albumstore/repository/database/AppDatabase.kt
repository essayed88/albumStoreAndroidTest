package com.leconcoin.test.albumstore.repository.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.leconcoin.test.albumstore.Album


const val DATABASE_NAME = "album_store"
@Database(entities = [Album::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun albumDao(): AlbumDao
}