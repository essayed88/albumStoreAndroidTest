package com.leconcoin.test.albumstore.albumslist

import com.leconcoin.test.albumstore.BaseActivity
import toothpick.config.Module

class AlbumsListModule private constructor() : Module() {

    constructor(baseActivity: BaseActivity) : this() {
        bind(IAlbumListViewModel::class.java).toInstance(
            baseActivity.getViewModel(
                AlbumListViewModelImpl::class.java
            )
        )
    }
}