package com.leconcoin.test.albumstore.albumslist

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.repository.database.AlbumDao
import com.leconcoin.test.albumstore.repository.database.fetch
import com.leconcoin.test.albumstore.repository.usecase.UpdateAlbumsUseCase
import javax.inject.Inject

class AlbumListViewModelImpl @Inject constructor() : ViewModel(), IAlbumListViewModel {

    private var albumListLiveData: MutableLiveData<List<Album>> = MutableLiveData()
    private var error: MutableLiveData<Throwable> = MutableLiveData()

    override fun observeAlbums(): MutableLiveData<List<Album>> = albumListLiveData

    override fun observeError(): MutableLiveData<Throwable> = error

    @Inject
    lateinit var updateAlbumsUseCase: UpdateAlbumsUseCase

    @Inject
    lateinit var albumDao: AlbumDao

    override fun fetchAlbums() {
        getAlbums()
        updateAlbums()
    }

    override fun updateAlbums() {
        updateAlbumsUseCase.execute()
            .fetch(error)
    }

    override fun getAlbums() {
        albumDao.getAllAlbums()
            .doOnNext {
                albumListLiveData.postValue(it)
            }
            .fetch(error)
    }
}