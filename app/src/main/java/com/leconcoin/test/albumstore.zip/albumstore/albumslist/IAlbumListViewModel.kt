package com.leconcoin.test.albumstore.albumslist

import androidx.lifecycle.MutableLiveData
import com.leconcoin.test.albumstore.Album

interface IAlbumListViewModel {

    fun observeAlbums(): MutableLiveData<List<Album>>
    fun observeError(): MutableLiveData<Throwable>
    fun updateAlbums()
    fun fetchAlbums()
    fun getAlbums()
}