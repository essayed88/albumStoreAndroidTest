package com.leconcoin.test.albumstore.albumDetail

import androidx.lifecycle.MutableLiveData
import com.leconcoin.test.albumstore.Album

interface IAlbumDetailViewModel {

    fun observeAlbum(): MutableLiveData<Album>
    fun observeError(): MutableLiveData<Throwable>
    fun getAlbumById(albumId: Int)
}