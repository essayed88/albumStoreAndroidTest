package com.leconcoin.test.albumstore.repository.usecase

import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.repository.api.AlbumClient
import com.leconcoin.test.albumstore.repository.database.AlbumDao
import io.reactivex.Single
import javax.inject.Inject

class UpdateAlbumsUseCase @Inject constructor() {

    @Inject
    lateinit var albumDao: AlbumDao
    @Inject
    lateinit var albumClient: AlbumClient

    fun execute(): Single<List<Album>> =
        albumClient.getAlbums()
            .doOnSuccess {
                albumDao.insertAlbums(it)
            }
}