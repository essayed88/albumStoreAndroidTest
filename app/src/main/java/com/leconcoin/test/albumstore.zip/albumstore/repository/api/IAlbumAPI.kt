package com.leconcoin.test.albumstore.repository.api

import com.leconcoin.test.albumstore.Album
import io.reactivex.Single
import retrofit2.http.GET

interface IAlbumAPI {

    @GET("img/shared/technical-test.json")
    fun getAlbums(): Single<List<Album>>
}