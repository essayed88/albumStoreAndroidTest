package com.leconcoin.test.albumstore.albumDetail

import com.leconcoin.test.albumstore.BaseActivity
import toothpick.config.Module

class AlbumDetailModule private constructor() : Module() {

    constructor(baseActivity: BaseActivity) : this() {
        bind(IAlbumDetailViewModel::class.java).toInstance(
            baseActivity.getViewModel(
                AlbumDetailViewModelImpl::class.java
            )
        )
    }
}