package com.leconcoin.test.albumstore.di

import android.app.Application
import android.content.res.Resources
import androidx.annotation.CallSuper
import androidx.lifecycle.ViewModel
import com.uber.autodispose.lifecycle.CorrespondingEventsFunction
import com.uber.autodispose.lifecycle.LifecycleEndedException
import com.uber.autodispose.lifecycle.LifecycleScopeProvider
import com.uber.autodispose.lifecycle.LifecycleScopes
import io.reactivex.CompletableSource
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject
import toothpick.Toothpick
import toothpick.config.Module

abstract class BaseViewModel(app: Application) : ViewModel(),
    LifecycleScopeProvider<BaseViewModel.ViewModelLifeCycleEvent> {

    private val viewModelInjectionModule: Module? = null

    private val scopeProvider by lazy { BehaviorSubject.create<ViewModelLifeCycleEvent>() }

    val resources: Resources = app.resources

    init {
        val viewModelScope = Toothpick.openScopes(app)
        if (viewModelInjectionModule != null) {
            viewModelScope.installModules(viewModelInjectionModule)
        }
        Toothpick.inject(toothpickConsumer(), viewModelScope)

        scopeProvider.onNext(ViewModelLifeCycleEvent.ON_CREATED)
    }

    private fun toothpickConsumer() = this

    @CallSuper
    override fun onCleared() {
        scopeProvider.onNext(ViewModelLifeCycleEvent.ON_CLEARED)
        super.onCleared()
    }

    override fun requestScope(): CompletableSource {
        return LifecycleScopes.resolveScopeFromLifecycle(this)
    }

    enum class ViewModelLifeCycleEvent {
        ON_CREATED, ON_CLEARED
    }

    override fun lifecycle(): Observable<ViewModelLifeCycleEvent> {
        return scopeProvider.hide()
    }

    override fun peekLifecycle(): ViewModelLifeCycleEvent? {
        return scopeProvider.value
    }

    override fun correspondingEvents(): CorrespondingEventsFunction<ViewModelLifeCycleEvent>? =
        CorrespondingEventsFunction { event ->
            when (event) {
                ViewModelLifeCycleEvent.ON_CREATED -> ViewModelLifeCycleEvent.ON_CLEARED
                ViewModelLifeCycleEvent.ON_CLEARED -> throw LifecycleEndedException()
            }
        }
}
