package com.leconcoin.test.albumstore.albumDetail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.albumDetail.IAlbumDetailViewModel
import com.leconcoin.test.albumstore.repository.database.fetch
import com.leconcoin.test.albumstore.repository.usecase.GetAlbumUseCase
import javax.inject.Inject

class AlbumDetailViewModelImpl @Inject constructor() : ViewModel(), IAlbumDetailViewModel {

    private var albumEvent: MutableLiveData<Album> = MutableLiveData()
    private var error: MutableLiveData<Throwable> = MutableLiveData()


    @Inject
    lateinit var getAlbumUseCase: GetAlbumUseCase

    override fun observeAlbum(): MutableLiveData<Album> = albumEvent
    override fun observeError(): MutableLiveData<Throwable> = error

    override fun getAlbumById(albumId: Int) {
        getAlbumUseCase.execute(albumId)
            .doOnSuccess { albumEvent.postValue(it) }
            .fetch(error)
    }
}