package com.leconcoin.test.albumstore.repository.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.leconcoin.test.albumstore.Album
import io.reactivex.Flowable
import io.reactivex.Single

@Dao
interface AlbumDao {

    @Query("SELECT * from album")
    fun getAllAlbums(): Flowable<List<Album>>

    @Query("SELECT * FROM album WHERE id = :id")
    fun getAlbumById(id: Int): Single<Album>

    @Insert
    fun insertAlbums(albums: List<Album>)
}