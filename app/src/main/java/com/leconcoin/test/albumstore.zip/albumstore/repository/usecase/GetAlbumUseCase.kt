package com.leconcoin.test.albumstore.repository.usecase

import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.repository.database.AlbumDao
import io.reactivex.Single
import javax.inject.Inject

class GetAlbumUseCase @Inject constructor() {

    @Inject
    lateinit var albumDao: AlbumDao

    fun execute(albumId: Int): Single<Album> = albumDao.getAlbumById(albumId)
}
