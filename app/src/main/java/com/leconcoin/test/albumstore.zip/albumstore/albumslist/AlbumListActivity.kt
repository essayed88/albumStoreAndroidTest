package com.leconcoin.test.albumstore.albumslist

import android.content.Intent
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.leconcoin.test.albumstore.Album
import com.leconcoin.test.albumstore.BaseActivity
import com.leconcoin.test.albumstore.R
import com.leconcoin.test.albumstore.albumDetail.AlbumDetailActivity
import com.leconcoin.test.albumstore.albumDetail.AlbumDetailModule
import kotlinx.android.synthetic.main.activity_album_list.*
import timber.log.Timber
import javax.inject.Inject


class AlbumsListActivity : BaseActivity(R.layout.activity_album_list),
    AlbumsListAdapter.AlbumsListAdapterListener {

    @Inject
    lateinit var viewModel: IAlbumListViewModel

    private lateinit var albumsAdapter: AlbumsListAdapter
    private lateinit var albums: MutableList<Album>


    override fun injectionModule() = AlbumDetailModule(this)

    override fun afterInject() {
        initUI()
        initData()
    }


    private fun initUI() {
        albums = mutableListOf()
        albumsAdapter = AlbumsListAdapter(albums, this)

        recyclerView?.apply {
            adapter = albumsAdapter
            layoutManager = LinearLayoutManager(this@AlbumsListActivity)

        }
        //swipeRefresh.setOnRefreshListener { viewModel.fetchAlbums() }
    }

    private fun initData() {
        viewModel.fetchAlbums()
        viewModel.observeAlbums().observe(this, Observer { newAlbums -> updateAlbums(newAlbums!!) })
    }

    private fun updateAlbums(newAlbums: List<Album>) {
        Timber.d("List of albums $newAlbums")
        albums.clear()
        albums.addAll(newAlbums)
        albumsAdapter.notifyDataSetChanged()
        //swipeRefresh.isRefreshing = false
    }

    override fun onAlbumSelected(album: Album) {
        val intent = Intent(this, AlbumDetailActivity::class.java)
        intent.putExtra(AlbumDetailActivity.EXTRA_BOOK_ID, album.id)
        startActivity(intent)
    }
}
