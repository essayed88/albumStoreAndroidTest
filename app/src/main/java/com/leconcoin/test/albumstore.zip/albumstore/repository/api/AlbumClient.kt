package com.leconcoin.test.albumstore.repository.api

import android.content.Context
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlbumClient @Inject constructor(private val context: Context) {

    private var albumApi: IAlbumAPI = ApiFactory.buildApi(context)

    fun getAlbums() = albumApi.getAlbums()
}